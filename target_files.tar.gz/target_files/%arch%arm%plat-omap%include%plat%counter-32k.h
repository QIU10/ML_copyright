int omap_init_clocksource_32k(void __iomem *vbase);
