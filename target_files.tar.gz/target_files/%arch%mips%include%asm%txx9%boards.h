/* SPDX-License-Identifier: GPL-2.0 */
#ifdef CONFIG_TOSHIBA_JMR3927
BOARD_VEC(jmr3927_vec)
#endif
#ifdef CONFIG_TOSHIBA_RBTX4927
BOARD_VEC(rbtx4927_vec)
BOARD_VEC(rbtx4937_vec)
#endif
#ifdef CONFIG_TOSHIBA_RBTX4938
BOARD_VEC(rbtx4938_vec)
#endif
#ifdef CONFIG_TOSHIBA_RBTX4939
BOARD_VEC(rbtx4939_vec)
#endif
