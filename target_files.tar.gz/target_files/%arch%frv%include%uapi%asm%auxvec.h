#ifndef __FRV_AUXVEC_H
#define __FRV_AUXVEC_H

#endif
